// src/modules/library/roads/markings/blockedAreaSvgs.ts
// Sperrflächen-Markierungen nach StVO (Zeichen 298)
// Original-SVGs von Illustrator, 1:1 als String
// Klassen/IDs pro Typ umbenannt um Konflikte bei mehreren Markierungen zu vermeiden

export type BlockedAreaDef = {
  /** Kompletter SVG-Body (alles innerhalb von <svg>...</svg>) */
  svgBody: string
  viewBox: string
  width: number
  height: number
}

// ============================================================================
// Sperrfläche Rechteck
// ============================================================================
const HATCH_RECT: BlockedAreaDef = {
  viewBox: '0 0 538 1138',
  width: 538,
  height: 1138,
  svgBody: `<defs>
    <style>.sr0,.sr1{fill:none}.sr2{fill:url(#hatch_rect);stroke-linejoin:round;stroke-width:18px}.sr2,.sr1{stroke:#fff}.sr1{stroke-width:16px}</style>
    <pattern id="hatch_rect" x="0" y="0" width="60" height="60" patternTransform="translate(-8553.26 -16532.35) rotate(-45) scale(1 -1)" patternUnits="userSpaceOnUse" viewBox="0 0 60 60">
      <g><rect class="sr0" width="60" height="60"/><line class="sr1" y1="60"/></g>
    </pattern>
  </defs>
  <polygon class="sr2" points="9 1129 9 9 529 9 529 1129 9 1129"/>`,
}

// ============================================================================
// Sperrfläche Keil (Dreieck)
// ============================================================================
const HATCH_WEDGE: BlockedAreaDef = {
  viewBox: '0 0 378 1058',
  width: 378,
  height: 1058,
  svgBody: `<defs>
    <style>.sw0,.sw1,.sw2{fill:none}.sw1{stroke-linejoin:round;stroke-width:18px}.sw1,.sw2{stroke:#fff}.sw2{stroke-linecap:square;stroke-width:14px}.sw3{clip-path:url(#clippath_wedge)}</style>
    <clipPath id="clippath_wedge"><polygon class="sw0" points="189 1049 9 9 369 9 189 1049"/></clipPath>
  </defs>
  <polygon class="sw1" points="189 1049 9 9 369 9 189 1049"/>
  <g class="sw3">
    <g>
      <line class="sw2" x1="509" y1="1009" x2="-131" y2="709"/>
      <line class="sw2" x1="509" y1="909" x2="-131" y2="609"/>
      <line class="sw2" x1="509" y1="809" x2="-131" y2="509"/>
      <line class="sw2" x1="509" y1="709" x2="-131" y2="409"/>
      <line class="sw2" x1="509" y1="609" x2="-131" y2="309"/>
      <line class="sw2" x1="509" y1="509" x2="-131" y2="209"/>
      <line class="sw2" x1="509" y1="409" x2="-131" y2="109"/>
      <line class="sw2" x1="509" y1="309" x2="-131" y2="9"/>
      <line class="sw2" x1="509" y1="209" x2="-131" y2="-91"/>
      <line class="sw2" x1="509" y1="109" x2="-131" y2="-191"/>
    </g>
  </g>`,
}

// ============================================================================
// Sperrfläche Keil abgerundet
// ============================================================================
const HATCH_WEDGE_ROUNDED: BlockedAreaDef = {
  viewBox: '0 0 900 1400',
  width: 900,
  height: 1400,
  svgBody: `<defs>
    <pattern id="hatch_rounded" patternUnits="userSpaceOnUse" width="60" height="60" patternTransform="rotate(-45)">
      <line x1="0" y1="0" x2="0" y2="60" stroke="white" stroke-width="14"/>
    </pattern>
    <path id="sperrflaeche_rounded" d="M470,90 C505,160 535,260 550,390 C565,520 575,690 585,900 C590,1015 596,1110 603,1185 C560,1148 520,1105 485,1055 C450,1005 420,955 397,905 C418,690 438,510 450,365 C460,250 467,160 470,90 Z"/>
    <clipPath id="clip_rounded"><use href="#sperrflaeche_rounded"/></clipPath>
  </defs>
  <rect x="0" y="0" width="900" height="1400" fill="url(#hatch_rounded)" clip-path="url(#clip_rounded)"/>
  <use href="#sperrflaeche_rounded" fill="none" stroke="white" stroke-width="16" stroke-linejoin="round" stroke-linecap="round"/>`,
}

// ============================================================================
// Sperrfläche Bogen
// ============================================================================
const HATCH_BOGEN: BlockedAreaDef = {
  viewBox: '0 0 500 1200',
  width: 500,
  height: 1200,
  svgBody: `<defs>
    <style>.sb0{fill:url(#hatch_bogen)}.sb1,.sb2{fill:none}.sb2{stroke:#fff;stroke-width:26px}</style>
    <pattern id="hatch_bogen" x="0" y="0" width="95" height="95" patternTransform="translate(-10492.05 -16143.57) rotate(-55) scale(1 -1)" patternUnits="userSpaceOnUse" viewBox="0 0 95 95">
      <g><rect class="sb1" width="95" height="95"/><line class="sb2" y1="95"/></g>
    </pattern>
  </defs>
  <polygon class="sb0" points="0 1200 0 0 500 0 500 1200 0 1200"/>`,
}

// ============================================================================
// Export-Map
// ============================================================================
export const BLOCKED_AREA_DEFS: Record<string, BlockedAreaDef> = {
  hatchRect: HATCH_RECT,
  hatchWedge: HATCH_WEDGE,
  hatchWedgeRounded: HATCH_WEDGE_ROUNDED,
  hatchBogen: HATCH_BOGEN,
}