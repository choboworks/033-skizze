// src/modules/library/roads/inspector/InteractiveRoadPreview.tsx
// Interaktive Live-Vorschau mit klickbaren Zonen - Hauptkomponente

import { useState, useRef, useEffect, useMemo } from 'react'
import type { SmartRoadConfig, RoadsideElementType } from '../types'
import { getActiveOrder, getMarkingX, getCrossMarkingBounds } from '../types'
import { ARROW_SVGS, ARROW_DEFS } from '../markings/arrowSvgs'
import { RotateCw, RotateCcw, Maximize2, X as XIcon } from 'lucide-react'

// Types & Constants
import type { HoveredZone, PopupPosition, ZoneType, ZoneSide } from './previewTypes'

// Hook
import { useRoadCalculations } from './hooks/useRoadCalculations'

// SVG Components
import { LeftSideElements } from './svg/LeftSideElements'
import { RightSideElements } from './svg/RightSideElements'
import { RoadSurface } from './svg/RoadSurface'
import { MedianAndLanes } from './svg/MedianAndLanes'
import { RampElement } from './svg/RampElement'

// Popups removed — ContextPanel in parent handles all options

type Props = {
  config: SmartRoadConfig
  updatePartial: (updates: Partial<SmartRoadConfig>) => void
  onZoneSelect?: (popup: PopupPosition) => void
}

export function InteractiveRoadPreview({ 
  config, 
  updatePartial,
  onZoneSelect,
}: Props) {
  const [hoveredZone, setHoveredZone] = useState<HoveredZone>(null)
  const [popup, setPopup] = useState<PopupPosition>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const svgContainerRef = useRef<HTMLDivElement>(null)
  
  // Dragging state für Markierungen
  const [draggingMarkingId, setDraggingMarkingId] = useState<string | null>(null)
  const [selectedMarkingId, setSelectedMarkingId] = useState<string | null>(null)
  const [dragMode, setDragMode] = useState<'move' | 'rotate' | 'scale' | null>(null)
  const dragOriginRef = useRef<{ x: number; y: number; startRotation: number; startScale: number } | null>(null)
  
  // Drag & Drop state für Seitenelemente
  const [draggedElement, setDraggedElement] = useState<RoadsideElementType | null>(null)
  const [dragSide, setDragSide] = useState<'left' | 'right' | null>(null)
  const [dropTargetIndex, setDropTargetIndex] = useState<number | null>(null)
  
  // Alle Berechnungen aus dem Hook
  const calc = useRoadCalculations(config)
  
  const markings = useMemo(() => config.markings || [], [config.markings])
  
  // Keyboard-Handler: Delete löscht ausgewählte Markierung, Escape deselektiert
  useEffect(() => {
    if (!selectedMarkingId) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault()
        updatePartial({ markings: markings.filter(m => m.id !== selectedMarkingId) })
        setSelectedMarkingId(null)
      } else if (e.key === 'Escape') {
        setSelectedMarkingId(null)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [selectedMarkingId, markings, updatePartial])
  
  // ========== DRAG & DROP FÜR SEITENELEMENTE ==========
  // Threshold-basiert: Klick öffnet Context, Drag startet erst nach Bewegung
  const dragStartRef = useRef<{ el: RoadsideElementType, side: 'left' | 'right', x: number, y: number } | null>(null)
  const DRAG_THRESHOLD = 5 // px Bewegung bevor Drag startet
  
  const handleDragMouseDown = (el: RoadsideElementType, side: 'left' | 'right', e: React.MouseEvent) => {
    if (e.button !== 0) return
    // Nur Drag-Intent speichern, noch kein Drag starten
    dragStartRef.current = { el, side, x: e.clientX, y: e.clientY }
  }
  
  const handleDragMouseMove = (e: React.MouseEvent) => {
    // Prüfe ob Drag-Intent existiert und Threshold überschritten
    if (dragStartRef.current && !draggedElement) {
      const dx = e.clientX - dragStartRef.current.x
      const dy = e.clientY - dragStartRef.current.y
      if (Math.abs(dx) + Math.abs(dy) > DRAG_THRESHOLD) {
        setDraggedElement(dragStartRef.current.el)
        setDragSide(dragStartRef.current.side)
        setDropTargetIndex(null)
      }
    }
  }
  
  const handleDragOver = (index: number) => {
    if (draggedElement) setDropTargetIndex(index)
  }
  
  const handleDrop = () => {
    dragStartRef.current = null
    
    if (!draggedElement || !dragSide || dropTargetIndex === null) {
      setDraggedElement(null)
      setDragSide(null)
      setDropTargetIndex(null)
      return
    }
    
    const k = dragSide === 'left' ? 'leftSide' : 'rightSide' as const
    const sc = config[k] || {}
    const currentOrder = getActiveOrder(sc)
    
    const fromIndex = currentOrder.indexOf(draggedElement)
    if (fromIndex === -1 || fromIndex === dropTargetIndex) {
      setDraggedElement(null)
      setDragSide(null)
      setDropTargetIndex(null)
      return
    }
    
    const newOrder = [...currentOrder]
    newOrder.splice(fromIndex, 1)
    const insertAt = dropTargetIndex > fromIndex ? dropTargetIndex - 1 : dropTargetIndex
    newOrder.splice(insertAt, 0, draggedElement)
    
    updatePartial({ [k]: { ...sc, order: newOrder } })
    
    setDraggedElement(null)
    setDragSide(null)
    setDropTargetIndex(null)
  }
  
  const handleDragMouseUp = (e: React.MouseEvent, zone: ZoneType, side: ZoneSide) => {
    if (draggedElement) {
      // War ein Drag — Drop ausführen
      handleDrop()
    } else if (dragStartRef.current) {
      // War ein Klick (kein Drag) — Context öffnen
      dragStartRef.current = null
      handleZoneClick(e, zone, undefined, side)
    }
  }
  
  // Global mouseup — nur aktiven Drag abbrechen
  useEffect(() => {
    const handleGlobalMouseUp = () => {
      if (draggedElement && dragSide) {
        // Inline Drop-Logik (vermeidet handleDrop dependency)
        if (dropTargetIndex !== null) {
          const k = dragSide === 'left' ? 'leftSide' : 'rightSide' as const
          const sc = config[k] || {}
          const currentOrder = getActiveOrder(sc)
          const fromIndex = currentOrder.indexOf(draggedElement)
          if (fromIndex !== -1 && fromIndex !== dropTargetIndex) {
            const newOrder = [...currentOrder]
            newOrder.splice(fromIndex, 1)
            const insertAt = dropTargetIndex > fromIndex ? dropTargetIndex - 1 : dropTargetIndex
            newOrder.splice(insertAt, 0, draggedElement)
            updatePartial({ [k]: { ...sc, order: newOrder } })
          }
        }
        setDraggedElement(null)
        setDragSide(null)
        setDropTargetIndex(null)
      }
    }
    window.addEventListener('mouseup', handleGlobalMouseUp)
    return () => window.removeEventListener('mouseup', handleGlobalMouseUp)
  }, [draggedElement, dragSide, dropTargetIndex, config, updatePartial])
  
  // Handle Zone Click
  const handleZoneClick = (
    e: React.MouseEvent, 
    zone: ZoneType, 
    index?: number, 
    side?: ZoneSide
  ) => {
    e.stopPropagation()
    const popupData: PopupPosition = {
      x: 0,
      y: 0,
      zone,
      side,
      index,
    }
    
    if (onZoneSelect) {
      onZoneSelect(popupData)
    } else {
      setPopup(popupData)
    }
  }

  // Handle Container Click (close popup/panel)
  const handleContainerClick = () => {
    setPopup(null)
    onZoneSelect?.(null)
  }
  
  // Close popup on ESC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setPopup(null)
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  // ========== CHANGE HANDLERS ==========
  
  // ========== RENDER ==========
  
  // Berechne Spurbreite und ob Spuren hinzugefügt/entfernt werden können
  const totalLanes = config.lanes
  const maxLanes = 8
  const minLanes = 1
  const canAddLane = totalLanes < maxLanes
  const canRemoveLane = totalLanes > minLanes
  
  // Spurbreite aus calc (berücksichtigt physische Trenner)
  const actualLaneWidth = calc.laneWidth > 0 ? Math.round(calc.laneWidth) : 40
  
  // Helper: Breite bei Spuränderung berechnen
  const widthForLanes = (newTotal: number) => {
    const newWidth = newTotal * actualLaneWidth + calc.totalPhysicalWidth
    return Math.max(80, newWidth)
  }
  
  // Button-Style Helpers
  const addBtnClass = "flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 hover:scale-105 active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed"
  const addBtnStyle: React.CSSProperties = { background: 'var(--primary)', color: 'white', boxShadow: '0 2px 8px rgba(59, 130, 246, 0.3)' }
  const removeBtnClass = "flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 hover:scale-105 active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed"
  const removeBtnStyle: React.CSSProperties = { background: 'var(--panel)', color: 'var(--text-muted)', border: '1px solid var(--border)', boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)' }
  
  const plusIcon = <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14" /></svg>
  const minusIcon = <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14" /></svg>
  
  return (
    <div 
      ref={containerRef}
      className="relative flex flex-col items-center gap-3"
    >
      {/* Oben: + Spur Button */}
      <button
        onClick={() => canAddLane && updatePartial({ lanes: totalLanes + 1, width: widthForLanes(totalLanes + 1) })}
        disabled={!canAddLane}
        className={addBtnClass}
        style={addBtnStyle}
        title="Spur hinzufügen"
      >
        {plusIcon}
        <span>Spur</span>
      </button>

      {/* Mittlerer Bereich: SVG */}
      <div className="flex items-center gap-4">

        {/* SVG Preview */}
        <div className="relative" ref={svgContainerRef}>
          <svg
            width={calc.displayWidth}
            height={calc.displayHeight}
            viewBox={`0 0 ${calc.totalWidth} ${config.length}`}
            style={{
              borderRadius: 'var(--radius-md)',
              overflow: 'hidden',
            }}
            onClick={handleContainerClick}
          >
        {/* Hintergrund/Bankett (hellgrau wie im Canvas) */}
        <rect
          x={0}
          y={0}
          width={calc.totalWidth}
          height={config.length}
          fill="#e5e7eb"
        />
        
        {/* Linke Seitenbereiche */}
        <LeftSideElements
          config={config}
          leftSideWidth={calc.leftSideWidth}
          elements={calc.leftElements}
          hoveredZone={hoveredZone}
          draggedElement={dragSide === 'left' ? draggedElement : null}
          dropTargetIndex={dragSide === 'left' ? dropTargetIndex : null}
          onHover={setHoveredZone}
          onDoubleClick={handleZoneClick}
          onDragMouseDown={handleDragMouseDown}
          onDragMouseMove={handleDragMouseMove}
          onDragMouseUp={handleDragMouseUp}
          onDragOver={handleDragOver}
        />
        
        {/* Fahrbahn */}
        <RoadSurface
          config={config}
          leftSideWidth={calc.leftSideWidth}
        />
        {/* Klickbare Fahrbahn-Zonen (links und rechts der Mitte, damit Median/Tram-Klicks nicht blockiert werden) */}
        {(() => {
          const roadX = calc.leftSideWidth
          const roadW = config.width
          const centerGap = 30 // Freiraum in der Mitte für Median/Tram-Klick
          const leftHalfW = roadW / 2 - centerGap / 2
          const rightHalfX = roadX + roadW / 2 + centerGap / 2
          const rightHalfW = roadW / 2 - centerGap / 2
          const isHovered = hoveredZone?.type === 'surface'
          const hoverFill = isHovered ? 'rgba(249, 115, 22, 0.15)' : 'transparent'
          
          return leftHalfW > 0 ? (
            <>
              <rect
                x={roadX} y={0} width={leftHalfW} height={config.length}
                fill={hoverFill}
                style={{ cursor: 'pointer' }}
                onMouseEnter={() => setHoveredZone({ type: 'surface' })}
                onMouseLeave={() => setHoveredZone(null)}
                onClick={(e) => handleZoneClick(e, 'surface')}
              />
              <rect
                x={rightHalfX} y={0} width={rightHalfW} height={config.length}
                fill={hoverFill}
                style={{ cursor: 'pointer' }}
                onMouseEnter={() => setHoveredZone({ type: 'surface' })}
                onMouseLeave={() => setHoveredZone(null)}
                onClick={(e) => handleZoneClick(e, 'surface')}
              />
            </>
          ) : null
        })()}
        
        {/* Beschleunigungsstreifen (direkt neben Fahrbahn, vor anderen Seitenelementen) */}
        {config.rightSide?.ramp && (
          <RampElement
            config={config}
            leftSideWidth={calc.leftSideWidth}
            hoveredZone={hoveredZone}
            onHover={setHoveredZone}
            onClick={handleZoneClick}
          />
        )}
        
        {/* Rechte Seitenbereiche (nach Beschleunigungsstreifen) */}
        <RightSideElements
          config={config}
          leftSideWidth={calc.leftSideWidth}
          elements={calc.rightElements}
          rightRampWidth={config.rightSide?.ramp ? 30 : 0}
          hoveredZone={hoveredZone}
          draggedElement={dragSide === 'right' ? draggedElement : null}
          dropTargetIndex={dragSide === 'right' ? dropTargetIndex : null}
          onHover={setHoveredZone}
          onDoubleClick={handleZoneClick}
          onDragMouseDown={handleDragMouseDown}
          onDragMouseMove={handleDragMouseMove}
          onDragMouseUp={handleDragMouseUp}
          onDragOver={handleDragOver}
        />
        
        {/* Straßenbahn-Gleise (vor Median, damit Mittellinien darüber liegen) */}
        {config.tram && config.category === 'strasse' && (() => {
          const tram = config.tram!
          const tramWidth = tram.width || (tram.tracks === 1 ? 20 : 36)
          const roadStart = calc.leftSideWidth
          const tramX = tram.position === 'left' 
            ? roadStart + 4
            : tram.position === 'right'
              ? roadStart + config.width - tramWidth - 4
              : roadStart + (config.width - tramWidth) / 2
          const gaugeWidth = 10
          const gap = 4
          const isHovered = hoveredZone?.type === 'tram'
          
          const renderRailPair = (centerX: number, key: string) => {
            const tieWidth = gaugeWidth + 6
            const showTies = tram.trackType === 'embedded'
            return (
              <g key={key}>
                {showTies && Array.from({ length: Math.floor(config.length / 20) }, (_, i) => {
                  const y = 10 + i * 20
                  return <rect key={`${key}-tie-${y}`} x={centerX - tieWidth / 2} y={y - 1.5} width={tieWidth} height={3} fill="#8b7355" opacity={0.6} />
                })}
                <line x1={centerX - gaugeWidth / 2} y1={0} x2={centerX - gaugeWidth / 2} y2={config.length} stroke="#c0c0c0" strokeWidth={2} />
                <line x1={centerX + gaugeWidth / 2} y1={0} x2={centerX + gaugeWidth / 2} y2={config.length} stroke="#c0c0c0" strokeWidth={2} />
              </g>
            )
          }
          
          return (
            <g className="tram-tracks">
              {/* Gleisbett */}
              <rect
                x={tramX} y={0} width={tramWidth} height={config.length}
                fill={tram.trackType === 'grass' ? '#6a8f4e' : tram.trackType === 'dedicated' ? '#888888' : '#5a5a5a'}
              />
              {/* Bordsteine bei dedicated/grass */}
              {(tram.trackType === 'dedicated' || tram.trackType === 'grass') && (
                <>
                  <line x1={tramX} y1={0} x2={tramX} y2={config.length} stroke="#999" strokeWidth={2} />
                  <line x1={tramX + tramWidth} y1={0} x2={tramX + tramWidth} y2={config.length} stroke="#999" strokeWidth={2} />
                </>
              )}
              {/* Schienen */}
              {tram.tracks === 1 
                ? renderRailPair(tramX + tramWidth / 2, 'track-0')
                : (
                  <>
                    {renderRailPair(tramX + tramWidth / 2 - gap / 2 - gaugeWidth / 2, 'track-0')}
                    {renderRailPair(tramX + tramWidth / 2 + gap / 2 + gaugeWidth / 2, 'track-1')}
                  </>
                )
              }
              {/* Klickbare Hover-Zone */}
              <rect
                x={tramX - 2} y={0} width={tramWidth + 4} height={config.length}
                fill={isHovered ? 'rgba(245, 158, 11, 0.25)' : 'transparent'}
                stroke={isHovered ? '#f59e0b' : 'transparent'}
                strokeWidth={isHovered ? 2 : 0}
                style={{ cursor: 'pointer' }}
                onMouseEnter={() => setHoveredZone({ type: 'tram' })}
                onMouseLeave={() => setHoveredZone(null)}
                onClick={(e) => handleZoneClick(e, 'tram')}
              />
            </g>
          )
        })()}

        {/* Median und Spurlinien (nach Tram, damit Linien darüber liegen) */}
        <MedianAndLanes
          config={config}
          leftSideWidth={calc.leftSideWidth}
          lines={calc.lines}
          showLaneLines={calc.showLaneLines}
          hoveredZone={hoveredZone}
          onHover={setHoveredZone}
          onClick={handleZoneClick}
        />
        
        
        {/* Fahrbahnmarkierungen */}
        {markings.map((marking) => {
          const yPosition = (marking.positionPercent / 100) * config.length
          const isDragging = draggingMarkingId === marking.id
          const isSelected = selectedMarkingId === marking.id
          const laneWidth = config.width / config.lanes
          
          // ===== PFEILE =====
          if (marking.type === 'arrow') {
            const def = ARROW_DEFS[marking.arrowType]
            if (!def) return null
            
            const scaleByWidth = (laneWidth * 0.6) / def.width
            const scaleByHeight = (config.length * 0.15) / def.height
            const baseScale = Math.min(scaleByWidth, scaleByHeight)
            
            const arrowWidth = def.width * baseScale
            const arrowHeight = def.height * baseScale
            const laneCenter = getMarkingX(marking, config.width, config.lanes, calc.leftSideWidth)
            const rotation = marking.rotation || 0
            const markingScale = marking.scale || 1
            
            const totalScale = baseScale * markingScale
            const scaledCenterX = (def.width / 2) * totalScale
            const scaledCenterY = (def.height / 2) * totalScale
            
            return (
              <g 
                key={marking.id}
                transform={`translate(${laneCenter}, ${yPosition})`}
                style={{ 
                  cursor: isDragging ? 'grabbing' : 'pointer',
                  filter: isDragging 
                    ? 'drop-shadow(0 4px 8px rgba(0,0,0,0.4))' 
                    : isSelected 
                      ? 'drop-shadow(0 0 6px rgba(59,130,246,0.6))' 
                      : 'drop-shadow(0 1px 2px rgba(0,0,0,0.3))',
                }}
              >
                <g transform={`rotate(${rotation})`}>
                  <g transform={`translate(${-scaledCenterX}, ${-scaledCenterY}) scale(${totalScale})`}>
                    <g dangerouslySetInnerHTML={{ __html: ARROW_SVGS[marking.arrowType] }} />
                  </g>
                  {isSelected && (
                    <rect
                      x={-arrowWidth * markingScale / 2 - 4}
                      y={-arrowHeight * markingScale / 2 - 4}
                      width={arrowWidth * markingScale + 8}
                      height={arrowHeight * markingScale + 8}
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth={1.5}
                      strokeDasharray="4 3"
                      rx={2}
                    />
                  )}
                </g>
                <rect
                  x={-arrowWidth * markingScale / 2 - 10}
                  y={-arrowHeight * markingScale / 2 - 10}
                  width={arrowWidth * markingScale + 20}
                  height={arrowHeight * markingScale + 20}
                  fill="transparent"
                  style={{ cursor: isDragging ? 'grabbing' : 'pointer' }}
                  onMouseDown={(e) => {
                    e.stopPropagation(); e.preventDefault()
                    setSelectedMarkingId(marking.id)
                    setDraggingMarkingId(marking.id)
                    setDragMode('move')
                    dragOriginRef.current = { x: e.clientX, y: e.clientY, startRotation: marking.rotation || 0, startScale: markingScale }
                  }}
                />
              </g>
            )
          }
          
          // ===== FAHRSTREIFENBEGRENZUNG (senkrecht, wie Spurlinie) =====
          if (marking.type === 'laneLine') {
            const xPos = getMarkingX(marking, config.width, config.lanes, calc.leftSideWidth)
            const rotation = marking.rotation || 0
            const ms = marking.scale || 1
            const lt = marking.lineType
            const lineH = config.length * 0.12 * ms  // Höhe des Liniensegments
            const gap = 3 * ms
            const halfH = lineH / 2
            
            const lineContent = (() => {
              if (lt === 'solid') {
                return <line x1={0} y1={-halfH} x2={0} y2={halfH} stroke="#ffffff" strokeWidth={2 * ms} />
              } else if (lt === 'double-solid') {
                return (
                  <>
                    <line x1={-gap/2} y1={-halfH} x2={-gap/2} y2={halfH} stroke="#ffffff" strokeWidth={1.5 * ms} />
                    <line x1={gap/2} y1={-halfH} x2={gap/2} y2={halfH} stroke="#ffffff" strokeWidth={1.5 * ms} />
                  </>
                )
              } else if (lt === 'solid-dashed') {
                return (
                  <>
                    <line x1={-gap/2} y1={-halfH} x2={-gap/2} y2={halfH} stroke="#ffffff" strokeWidth={1.5 * ms} />
                    <line x1={gap/2} y1={-halfH} x2={gap/2} y2={halfH} stroke="#ffffff" strokeWidth={1.5 * ms} strokeDasharray={`${4 * ms} ${3 * ms}`} />
                  </>
                )
              } else {
                return (
                  <>
                    <line x1={-gap/2} y1={-halfH} x2={-gap/2} y2={halfH} stroke="#ffffff" strokeWidth={1.5 * ms} strokeDasharray={`${4 * ms} ${3 * ms}`} />
                    <line x1={gap/2} y1={-halfH} x2={gap/2} y2={halfH} stroke="#ffffff" strokeWidth={1.5 * ms} />
                  </>
                )
              }
            })()
            
            const hitW = 12 * ms
            
            return (
              <g key={marking.id} transform={`translate(${xPos}, ${yPosition})`}
                style={{
                  cursor: isDragging ? 'grabbing' : 'pointer',
                  filter: isSelected ? 'drop-shadow(0 0 6px rgba(59,130,246,0.6))' : 'drop-shadow(0 1px 2px rgba(0,0,0,0.3))',
                }}
              >
                <g transform={rotation ? `rotate(${rotation})` : undefined}>
                  {lineContent}
                  {isSelected && (
                    <rect x={-hitW/2 - 2} y={-halfH - 2} width={hitW + 4} height={lineH + 4}
                      fill="none" stroke="#3b82f6" strokeWidth={1} strokeDasharray="4 3" rx={1} />
                  )}
                </g>
                <rect x={-hitW/2 - 5} y={-halfH - 5} width={hitW + 10} height={lineH + 10}
                  fill="transparent" style={{ cursor: isDragging ? 'grabbing' : 'pointer' }}
                  onMouseDown={(e) => {
                    e.stopPropagation(); e.preventDefault()
                    setSelectedMarkingId(marking.id)
                    setDraggingMarkingId(marking.id)
                    setDragMode('move')
                    dragOriginRef.current = { x: e.clientX, y: e.clientY, startRotation: marking.rotation || 0, startScale: ms }
                  }}
                />
              </g>
            )
          }
          
          // ===== HALTELINIE / WARTELINIE / HAIFISCHZÄHNE =====
          if (marking.type === 'stopLine' || marking.type === 'waitLine' || marking.type === 'sharkTeeth') {
            const { x1, x2, centerX, lineWidth } = getCrossMarkingBounds(marking, config.width, calc.leftSideWidth)
            const rotation = marking.rotation || 0
            const ms = marking.scale || 1
            const thickness = marking.type === 'stopLine' ? 3 : 2
            
            const lineContent = (() => {
              if (marking.type === 'stopLine') {
                return <rect x={x1} y={yPosition - thickness * ms / 2} width={lineWidth} height={thickness * ms} fill="#ffffff" />
              } else if (marking.type === 'waitLine') {
                const dashLen = 4
                const gapLen = 4
                const segments: React.ReactElement[] = []
                let cx = x1
                let i = 0
                while (cx < x2) {
                  const w = Math.min(dashLen, x2 - cx)
                  segments.push(<rect key={i} x={cx} y={yPosition - thickness * ms / 2} width={w} height={thickness * ms} fill="#ffffff" />)
                  cx += dashLen + gapLen
                  i++
                }
                return <>{segments}</>
              } else {
                const toothW = 6 * ms
                const toothH = 8 * ms
                const gap = 2 * ms
                const dir = marking.direction === 'outward' ? -1 : 1
                const triangles: React.ReactElement[] = []
                let cx = x1
                let i = 0
                while (cx + toothW <= x2 + 0.1) {
                  const ty = dir > 0 ? yPosition - toothH / 2 : yPosition + toothH / 2
                  const by = dir > 0 ? yPosition + toothH / 2 : yPosition - toothH / 2
                  triangles.push(
                    <polygon key={i} points={`${cx},${by} ${cx + toothW / 2},${ty} ${cx + toothW},${by}`} fill="#ffffff" />
                  )
                  cx += toothW + gap
                  i++
                }
                return <>{triangles}</>
              }
            })()
            
            return (
              <g key={marking.id} transform={rotation ? `rotate(${rotation}, ${centerX}, ${yPosition})` : undefined}>
                <g style={{
                  filter: isSelected ? 'drop-shadow(0 0 4px rgba(59,130,246,0.6))' : undefined,
                }}>
                  {lineContent}
                </g>
                {isSelected && (
                  <rect x={x1 - 3} y={yPosition - 8 * ms} width={lineWidth + 6} height={16 * ms}
                    fill="none" stroke="#3b82f6" strokeWidth={1} strokeDasharray="4 3" rx={1} />
                )}
                <rect x={x1 - 5} y={yPosition - 12} width={lineWidth + 10} height={24}
                  fill="transparent" style={{ cursor: 'pointer' }}
                  onMouseDown={(e) => {
                    e.stopPropagation(); e.preventDefault()
                    setSelectedMarkingId(marking.id)
                    setDraggingMarkingId(marking.id)
                    setDragMode('move')
                    dragOriginRef.current = { x: e.clientX, y: e.clientY, startRotation: rotation, startScale: ms }
                  }}
                />
              </g>
            )
          }
          
          // ===== SPERRFLÄCHEN =====
          if (marking.type === 'blockedArea') {
            const { x1, centerX, lineWidth: areaWidth } = getCrossMarkingBounds(marking, config.width, calc.leftSideWidth)
            const rotation = marking.rotation || 0
            const ms = marking.scale || 1
            const hPct = marking.heightPercent ?? 15
            const areaHeight = (hPct / 100) * config.length * ms
            const halfH = areaHeight / 2
            const at = marking.areaType
            const x2 = x1 + areaWidth
            
            // Pattern-ID unique per marking
            const patternId = `pattern-${marking.id}`
            
            // Hatch pattern (diagonal stripes for all sperrflächen types)
            const hatchPattern = (
              <pattern id={patternId} width={8 * ms} height={8 * ms} patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
                <line x1={0} y1={0} x2={0} y2={8 * ms} stroke="#ffffff" strokeWidth={1.5 * ms} />
              </pattern>
            )
            
            // Shape: rect or wedge (trapezoid tapering to point at bottom)
            const yTop = yPosition - halfH
            const yBot = yPosition + halfH
            
            let shapePath: string
            if (at === 'hatchWedge' || at === 'hatchWedgeRounded') {
              shapePath = `M${x1},${yTop} L${x2},${yTop} L${x2},${yTop + areaHeight * 0.4} Q${x2},${yBot - areaHeight * 0.1} ${centerX},${yBot} Q${x1},${yBot - areaHeight * 0.1} ${x1},${yTop + areaHeight * 0.4} Z`
            } else {
              shapePath = `M${x1},${yTop} L${x2},${yTop} L${x2},${yBot} L${x1},${yBot} Z`
            }
            
            return (
              <g key={marking.id} transform={rotation ? `rotate(${rotation}, ${centerX}, ${yPosition})` : undefined}>
                <defs>
                  {hatchPattern}
                </defs>
                <g style={{ filter: isSelected ? 'drop-shadow(0 0 4px rgba(59,130,246,0.6))' : undefined }}>
                  {/* Border + Fill */}
                  <path d={shapePath} fill={`url(#${patternId})`} stroke="#ffffff" strokeWidth={2 * ms} />
                </g>
                {isSelected && (
                  <rect x={x1 - 3} y={yTop - 3} width={areaWidth + 6} height={areaHeight + 6}
                    fill="none" stroke="#3b82f6" strokeWidth={1} strokeDasharray="4 3" rx={1} />
                )}
                <rect x={x1 - 5} y={yTop - 5} width={areaWidth + 10} height={areaHeight + 10}
                  fill="transparent" style={{ cursor: 'pointer' }}
                  onMouseDown={(e) => {
                    e.stopPropagation(); e.preventDefault()
                    setSelectedMarkingId(marking.id)
                    setDraggingMarkingId(marking.id)
                    setDragMode('move')
                    dragOriginRef.current = { x: e.clientX, y: e.clientY, startRotation: rotation, startScale: ms }
                  }}
                />
              </g>
            )
          }
          
          return null
        })}
          </svg>
          
          {/* Interaktives Markierungs-Overlay - für Drag, Doppelklick, Scroll */}
          <div
            className="absolute inset-0"
            style={{
              cursor: draggingMarkingId ? (dragMode === 'rotate' ? 'grabbing' : dragMode === 'scale' ? 'nwse-resize' : 'grabbing') : 'default',
              pointerEvents: (draggingMarkingId || selectedMarkingId) ? 'auto' : 'none',
            }}
            onMouseDown={(e) => {
              // Klick auf leere Fläche → Deselect
              const rect = svgContainerRef.current?.getBoundingClientRect()
              if (!rect) return
              
              const clickX = e.clientX - rect.left
              const clickY = e.clientY - rect.top
              
              const scaleX = calc.totalWidth / calc.displayWidth
              const scaleY = config.length / calc.displayHeight
              
              const configX = clickX * scaleX
              const configY = clickY * scaleY
              
              const laneWidth = config.width / (config.lanes)
              const arrowWidth = laneWidth * 0.6
              const arrowHeight = arrowWidth * 1.2
              
              for (const marking of markings) {
                const yPos = (marking.positionPercent / 100) * config.length
                
                // Quermarkierungen (stopLine, waitLine) — ganze Fahrbahnbreite
                if (marking.type === 'stopLine' || marking.type === 'waitLine') {
                  const roadLeft = calc.leftSideWidth
                  const roadRight = calc.leftSideWidth + config.width
                  if (configX >= roadLeft - 5 && configX <= roadRight + 5 && configY >= yPos - 12 && configY <= yPos + 12) {
                    setSelectedMarkingId(marking.id)
                    setDraggingMarkingId(marking.id)
                    setDragMode('move')
                    dragOriginRef.current = { x: e.clientX, y: e.clientY, startRotation: 0, startScale: 1 }
                    e.preventDefault(); e.stopPropagation()
                    return
                  }
                  continue
                }
                
                // Pfeile + SpeedNumber — Spur-basiert
                if (marking.type !== 'arrow' && marking.type !== 'speedNumber' && marking.type !== 'laneLine') continue
                const ms = marking.scale || 1
                const laneCenter = getMarkingX(marking, config.width, config.lanes, calc.leftSideWidth)
                
                const hw = arrowWidth * ms / 2 + 15
                const hh = arrowHeight * ms / 2 + 15
                
                if (configX >= laneCenter - hw && configX <= laneCenter + hw && configY >= yPos - hh && configY <= yPos + hh) {
                  setSelectedMarkingId(marking.id)
                  setDraggingMarkingId(marking.id)
                  setDragMode('move')
                  dragOriginRef.current = { x: e.clientX, y: e.clientY, startRotation: marking.rotation || 0, startScale: ms }
                  e.preventDefault(); e.stopPropagation()
                  return
                }
              }
              // Nichts getroffen → deselect
              setSelectedMarkingId(null)
            }}
            onMouseMove={(e) => {
              if (!draggingMarkingId || !dragMode) return
              
              const rect = svgContainerRef.current?.getBoundingClientRect()
              if (!rect) return
              
              if (dragMode === 'move') {
                const clickX = e.clientX - rect.left
                const clickY = e.clientY - rect.top
                
                const scaleX = calc.totalWidth / calc.displayWidth
                const scaleY = config.length / calc.displayHeight
                
                const configX = clickX * scaleX
                const configY = clickY * scaleY
                
                const roadX = configX - calc.leftSideWidth
                const laneWidth = config.width / (config.lanes)
                const positionPercent = Math.max(5, Math.min(95, (configY / config.length) * 100))
                
                // Shift gedrückt → freie Platzierung (xPercent), sonst Snap-to-Lane
                const isFreeMode = e.shiftKey
                
                const newMarkings = markings.map(m => {
                  if (m.id !== draggingMarkingId) return m
                  
                  // Quermarkierungen: Snap oder frei
                  if (m.type === 'stopLine' || m.type === 'waitLine' || m.type === 'sharkTeeth' || m.type === 'blockedArea') {
                    const xPct = Math.max(0, Math.min(100, (roadX / config.width) * 100))
                    const wPct = m.widthPercent ?? 100
                    
                    if (isFreeMode) {
                      // Shift: frei positionieren
                      return { ...m, positionPercent, xPercent: xPct }
                    } else if (wPct < 100) {
                      // Halbe: snap zur linken (25%) oder rechten (75%) Hälfte
                      const snappedX = xPct < 50 ? wPct / 2 : 100 - wPct / 2
                      return { ...m, positionPercent, xPercent: snappedX }
                    } else {
                      // Volle Breite: nur Y verschieben, X auf Mitte
                      const updated = { ...m, positionPercent }
                      delete (updated as { xPercent?: number }).xPercent
                      return updated
                    }
                  }
                  
                  if (isFreeMode) {
                    const xPercent = Math.max(0, Math.min(100, (roadX / config.width) * 100))
                    return { ...m, xPercent, positionPercent }
                  } else {
                    const laneIndex = Math.max(0, Math.min(config.lanes - 1, Math.floor(roadX / laneWidth)))
                    const updated = { ...m, laneIndex, positionPercent }
                    delete (updated as { xPercent?: number }).xPercent
                    return updated
                  }
                })
                updatePartial({ markings: newMarkings })
                
              } else if (dragMode === 'rotate' && dragOriginRef.current) {
                const marking = markings.find(m => m.id === draggingMarkingId)
                if (!marking) return
                
                // Zentrum der Markierung berechnen (generisch für alle Typen)
                let centerX: number, centerY: number
                const yPos = (marking.positionPercent / 100) * config.length
                
                if (marking.type === 'stopLine' || marking.type === 'waitLine' || marking.type === 'sharkTeeth' || marking.type === 'blockedArea') {
                  const bounds = getCrossMarkingBounds(marking, config.width, calc.leftSideWidth)
                  centerX = bounds.centerX
                  centerY = yPos
                } else if ('laneIndex' in marking) {
                  centerX = getMarkingX(marking as { laneIndex: number; xPercent?: number }, config.width, config.lanes, calc.leftSideWidth)
                  centerY = yPos
                } else {
                  return
                }
                
                const screenScaleX = calc.displayWidth / calc.totalWidth
                const screenScaleY = calc.displayHeight / config.length
                const centerScreenX = rect.left + centerX * screenScaleX
                const centerScreenY = rect.top + centerY * screenScaleY
                
                // Winkel von Zentrum zum Mauszeiger
                const dx = e.clientX - centerScreenX
                const dy = e.clientY - centerScreenY
                const angle = Math.atan2(dx, -dy) * (180 / Math.PI)
                
                let newRotation = Math.round(angle / 5) * 5 // 5°-Snapping
                if (newRotation < 0) newRotation += 360
                
                const newMarkings = markings.map(m => 
                  m.id === draggingMarkingId ? { ...m, rotation: newRotation } : m
                )
                updatePartial({ markings: newMarkings })
                
              } else if (dragMode === 'scale' && dragOriginRef.current) {
                // Scale basierend auf vertikaler Distanz (runter = größer, hoch = kleiner)
                const dy = e.clientY - dragOriginRef.current.y
                const scaleChange = dy / 150
                const newScale = Math.max(0.3, Math.min(3, dragOriginRef.current.startScale + scaleChange))
                
                const newMarkings = markings.map(m =>
                  m.id === draggingMarkingId ? { ...m, scale: Math.round(newScale * 100) / 100 } : m
                )
                updatePartial({ markings: newMarkings })
              }
            }}
            onMouseUp={() => {
              setDraggingMarkingId(null)
              setDragMode(null)
              dragOriginRef.current = null
            }}
            onMouseLeave={() => {
              setDraggingMarkingId(null)
              setDragMode(null)
              dragOriginRef.current = null
            }}
            onDoubleClick={(e) => {
              // Lösche Markierung bei Doppelklick
              const rect = svgContainerRef.current?.getBoundingClientRect()
              if (!rect) return
              
              const clickX = e.clientX - rect.left
              const clickY = e.clientY - rect.top
              
              const scaleX = calc.totalWidth / calc.displayWidth
              const scaleY = config.length / calc.displayHeight
              
              const configX = clickX * scaleX
              const configY = clickY * scaleY
              
              const laneWidth = config.width / (config.lanes)
              const arrowWidth = laneWidth * 0.6
              const arrowHeight = arrowWidth * 1.2
              
              for (const marking of markings) {
                const yPos = (marking.positionPercent / 100) * config.length
                
                // Quermarkierungen
                if (marking.type === 'stopLine' || marking.type === 'waitLine' || marking.type === 'sharkTeeth' || marking.type === 'blockedArea') {
                  if (configX >= calc.leftSideWidth - 5 && configX <= calc.leftSideWidth + config.width + 5 && configY >= yPos - 12 && configY <= yPos + 12) {
                    updatePartial({ markings: markings.filter(m => m.id !== marking.id) })
                    setSelectedMarkingId(null)
                    return
                  }
                  continue
                }
                
                if (marking.type !== 'arrow' && marking.type !== 'speedNumber' && marking.type !== 'laneLine') continue
                const ms = marking.scale || 1
                const laneCenter = getMarkingX(marking, config.width, config.lanes, calc.leftSideWidth)
                
                const hw = arrowWidth * ms / 2 + 15
                const hh = arrowHeight * ms / 2 + 15
                
                if (configX >= laneCenter - hw && configX <= laneCenter + hw && configY >= yPos - hh && configY <= yPos + hh) {
                  updatePartial({ markings: markings.filter(m => m.id !== marking.id) })
                  setSelectedMarkingId(null)
                  return
                }
              }
            }}
            onWheel={(e) => {
              // Rotiere ausgewählte Markierung mit Scroll-Rad
              if (!selectedMarkingId) return
              const marking = markings.find(m => m.id === selectedMarkingId)
              if (!marking) return
              
              e.preventDefault()
              e.stopPropagation()
              
              const rotationDelta = e.deltaY > 0 ? 15 : -15
              const currentRotation = marking.rotation || 0
              let newRotation = (currentRotation + rotationDelta) % 360
              if (newRotation < 0) newRotation += 360
              
              const newMarkings = markings.map(m => 
                m.id === selectedMarkingId ? { ...m, rotation: newRotation } : m
              )
              updatePartial({ markings: newMarkings })
            }}
          />
          
          {/* HTML-basierte Selection-Handles — für ALLE ausgewählten Markierungen */}
          {selectedMarkingId && !draggingMarkingId && (() => {
            const marking = markings.find(m => m.id === selectedMarkingId)
            if (!marking) return null
            
            const ms = marking.scale || 1
            const yPos = (marking.positionPercent / 100) * config.length
            
            // Bounding-Box der Markierung berechnen (generisch)
            let centerX: number, halfW: number, halfH: number
            
            if (marking.type === 'stopLine' || marking.type === 'waitLine' || marking.type === 'sharkTeeth' || marking.type === 'blockedArea') {
              const bounds = getCrossMarkingBounds(marking, config.width, calc.leftSideWidth)
              centerX = bounds.centerX
              halfW = (bounds.lineWidth / 2 + 6) * ms
              halfH = (marking.type === 'sharkTeeth' ? 10 : 5) * ms
            } else if ('laneIndex' in marking) {
              const laneWidth = config.width / config.lanes
              const arrowWidth = laneWidth * 0.6
              const arrowHeight = arrowWidth * 1.2
              centerX = getMarkingX(marking as { laneIndex: number; xPercent?: number }, config.width, config.lanes, calc.leftSideWidth)
              halfW = (arrowWidth * ms / 2 + 6)
              halfH = (arrowHeight * ms / 2 + 6)
            } else {
              return null
            }
            
            // Konvertiere Config-Koordinaten → Screen-Pixel
            const screenScaleX = calc.displayWidth / calc.totalWidth
            const screenScaleY = calc.displayHeight / config.length
            const cx = centerX * screenScaleX
            const cy = yPos * screenScaleY
            const hw = halfW * screenScaleX
            const hh = halfH * screenScaleY
            
            const handleSize = 28
            
            return (
              <>
                {/* Rotation-Handle — oben mittig */}
                <button
                  className="absolute flex items-center justify-center rounded-full shadow-lg transition-transform hover:scale-110 active:scale-95"
                  style={{
                    width: handleSize,
                    height: handleSize,
                    left: cx - handleSize / 2,
                    top: cy - hh - handleSize - 6,
                    background: 'white',
                    border: '2px solid #3b82f6',
                    color: '#3b82f6',
                    cursor: 'grab',
                    pointerEvents: 'auto',
                    zIndex: 60,
                  }}
                  onMouseDown={(e) => {
                    e.stopPropagation()
                    e.preventDefault()
                    setDraggingMarkingId(marking.id)
                    setDragMode('rotate')
                    dragOriginRef.current = { x: e.clientX, y: e.clientY, startRotation: marking.rotation || 0, startScale: ms }
                  }}
                  title="Rotieren"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>
                
                {/* Scale-Handle — unten rechts */}
                <button
                  className="absolute flex items-center justify-center rounded-md shadow-lg transition-transform hover:scale-110 active:scale-95"
                  style={{
                    width: handleSize,
                    height: handleSize,
                    left: cx + hw - handleSize / 2 + 2,
                    top: cy + hh - handleSize / 2 + 2,
                    background: 'white',
                    border: '2px solid #3b82f6',
                    color: '#3b82f6',
                    cursor: 'nwse-resize',
                    pointerEvents: 'auto',
                    zIndex: 60,
                  }}
                  onMouseDown={(e) => {
                    e.stopPropagation()
                    e.preventDefault()
                    setDraggingMarkingId(marking.id)
                    setDragMode('scale')
                    dragOriginRef.current = { x: e.clientX, y: e.clientY, startRotation: marking.rotation || 0, startScale: ms }
                  }}
                  title="Größe ändern"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>
                
                {/* Delete-Handle — oben rechts */}
                <button
                  className="absolute flex items-center justify-center rounded-full shadow-lg transition-transform hover:scale-110 active:scale-95"
                  style={{
                    width: handleSize - 4,
                    height: handleSize - 4,
                    left: cx + hw + 2,
                    top: cy - hh - handleSize / 2,
                    background: '#ef4444',
                    border: '2px solid #ef4444',
                    color: 'white',
                    cursor: 'pointer',
                    pointerEvents: 'auto',
                    zIndex: 60,
                  }}
                  onClick={(e) => {
                    e.stopPropagation()
                    updatePartial({ markings: markings.filter(m => m.id !== marking.id) })
                    setSelectedMarkingId(null)
                  }}
                  title="Löschen"
                >
                  <XIcon className="w-3 h-3" />
                </button>
                
                {/* Reset-Handle — unten links (nur wenn rotiert oder skaliert) */}
                {((marking.rotation && marking.rotation !== 0) || (marking.scale && marking.scale !== 1)) && (
                  <button
                    className="absolute flex items-center justify-center rounded-full shadow-lg transition-transform hover:scale-110 active:scale-95"
                    style={{
                      width: handleSize - 4,
                      height: handleSize - 4,
                      left: cx - hw - handleSize / 2,
                      top: cy + hh + 2,
                      background: 'white',
                      border: '2px solid #f59e0b',
                      color: '#f59e0b',
                      cursor: 'pointer',
                      pointerEvents: 'auto',
                      zIndex: 60,
                    }}
                    onClick={(e) => {
                      e.stopPropagation()
                      updatePartial({ markings: markings.map(m => m.id === marking.id ? { ...m, rotation: 0, scale: 1 } : m) })
                    }}
                    title="Rotation & Größe zurücksetzen"
                  >
                    <RotateCcw className="w-3 h-3" />
                  </button>
                )}
              </>
            )
          })()}
          
          
          {/* Hover-Hint */}
          {!popup && hoveredZone && (
            <div 
              className="absolute bottom-2 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-md text-xs font-medium"
              style={{
                background: 'rgba(0,0,0,0.8)',
                color: 'white',
                pointerEvents: 'none',
              }}
            >
              {hoveredZone.type === 'surface' && 'Fahrbahnbelag'}
              {hoveredZone.type === 'median' && 'Mittellinie'}
              {hoveredZone.type === 'laneLine' && `Spurlinie ${(hoveredZone.index || 0) + 1}`}
              {hoveredZone.type === 'sidewalk' && `Gehweg ${hoveredZone.side === 'left' ? 'links' : 'rechts'}`}
              {hoveredZone.type === 'cyclePath' && `Radweg-Fläche ${hoveredZone.side === 'left' ? 'links' : 'rechts'}`}
              {hoveredZone.type === 'cyclePathLine' && `Radweg-Linie ${hoveredZone.side === 'left' ? 'links' : 'rechts'}`}
              {hoveredZone.type === 'onRoadCyclePath' && `Radstreifen ${hoveredZone.side === 'left' ? 'links' : 'rechts'}`}
              {hoveredZone.type === 'onRoadCyclePathLine' && `Radstreifen-Linie ${hoveredZone.side === 'left' ? 'links' : 'rechts'}`}
              {hoveredZone.type === 'curb' && `Bordstein ${hoveredZone.side === 'left' ? 'links' : 'rechts'}`}
              {hoveredZone.type === 'greenStrip' && `Grünfläche ${hoveredZone.side === 'left' ? 'links' : 'rechts'}`}
              {hoveredZone.type === 'barrier' && `Leitplanke ${hoveredZone.side === 'left' ? 'links' : 'rechts'}`}
              {hoveredZone.type === 'emergencyLane' && `Standstreifen ${hoveredZone.side === 'left' ? 'links' : 'rechts'}`}
              {hoveredZone.type === 'parking' && `Parkplätze ${hoveredZone.side === 'left' ? 'links' : 'rechts'}`}
              {hoveredZone.type === 'ramp' && 'Beschleunigungsstreifen'}
              {hoveredZone.type === 'tram' && '🚋 Straßenbahn-Gleise'}
            </div>
          )}
        </div>
      </div>

      {/* Unten: - Spur Button */}
      <button
        onClick={() => canRemoveLane && updatePartial({ lanes: Math.max(1, totalLanes - 1), width: widthForLanes(totalLanes - 1) })}
        disabled={!canRemoveLane}
        className={removeBtnClass}
        style={removeBtnStyle}
        title="Spur entfernen"
      >
        {minusIcon}
        <span>Spur</span>
      </button>
    </div>
  )
}